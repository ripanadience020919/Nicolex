  <footer class="footer">
           
              <span class="text-muted text-center footer-copyright">Copyright © 2019 | All rights reserved.</span>
             
         
          </footer>
        </div>
      </div>
    </div>
    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/vendor.bundle.base.js"></script>
    <script src="js/hoverable-collapse.js"></script>
    <script src="js/misc.js"></script>
    <script src="js/dashboard.js"></script>
	<script src="js/off-canvas.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/datepicker.min.js"></script>
   <script>
   $('.advertisement-slider.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
	autoplay:true,
	nav:false,
	 responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:2,
            nav:false
        },
        1000:{
            items:3,
            nav:true,
            loop:false
        }
    }
})

</script>
  </body>
</html>