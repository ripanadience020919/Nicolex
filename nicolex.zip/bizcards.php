 <?php include("userheader.php"); ?>
 <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
   <?php include("sidebar.php"); 
   $bizcard=new Users;
          
 ?>
   <!-- partial -->
   
        <div class="main-panel">
          <div class="content-wrapper">
 
            <div class="page-header">
              <h3 class="page-title">MyBizCards </h3>
            </div>
			<div class="dashboard-select">
                
			    <div class="row" >
            <form class="business-form"  method="post" action="" enctype="multipart/form-data" id="pcnform" >
                 <input type="hidden" name="page" value="business" />
				   <div class="col-md-12">
				     <div class="input-field">
					  <label class="input-label">Enter Your Valid PCN Code<sup> *</sup></label>
					  <input type="text" class="form-control" name="code" required>
					 </div>
				   </div>
				    <div class="col-md-12">
				  <div class="submit-form-btn">
					   <input type="submit" Value="Submit" name="submit2" />
					 </div>
				  </div>
				   </form>
				   </div>
				   
			 <div class="row">
              <?php       
    if(isset($_POST['submit2'])){
                                 if($_POST['code']!=''){
                                     $table=substr($_POST['code'],6,3); 
                                 $user=$bizcard->getwheredata('user', 'id', $_SESSION['id']);
                                 $ap=$user[0]['bizcardapproval'];
                                 if($ap=='N'){
                                 $support=$bizcard->getcomparepcn($_SESSION['id'],$_POST['code'],$table);
                                 if($support=='done'){
                                     ?>
				   <div class="col-lg-6">
			      <div class="mybizcard-box">
				    <div class="row">
					<div class="col-sm-4">
				        <a href="userprofile.php?id=<?php echo $userbiz['id'];?>">
					  <div class="mybiz-img">
					     <img src="images/user/<?php echo $userbiz['image'];?>" alt="">
                                             <?php if($userbiz['image']==''){ echo '<img src="images/edit-pic.png" alt="image">';}else{echo '<img src="images/user/'.$userbiz['image'].' alt="">';}?>
                                             
					  </div>
					  </a>
					  </div>
					  <div class="col-sm-8">
					  <div class="mybizcrd-txt">
					     <h3><?php echo $userbiz['name']; ?></h3>
						 <p><?php echo $userbiz['about'];?></p>
						 <a href="#">Request </a>
						 <a href="#">mail </a>
					  </div>
					  </div>
					</div>
				  </div>
				     </div>
                                   
                                     <?php
                                 }else{ echo ' <div class="business-warning"> <p>Invalid PCN Number.</p> </div>'; }
                                 }else{
                                     ///////////// y h then show kr do 
                               
                                 ?>
			 <?php 
                   $usertax=$bizcard->getbizcarddata($_SESSION['id']);
                   if($usertax=='nodata'){ echo '<div class="col-lg-12"> <div class="business-warning"> <p>No Other Person Of Your Business Category.</p> </div></div>';}
                   elseif($usertax=='pay'){ echo '<div class="col-lg-12"> <div class="business-warning"> <p>Please Pay the Tax First.</p> </div></div>';}
                   else{    //print_r($usertax);
                       foreach ($usertax as $usertaxvalue) {  
                           for ($i = 0; $i<1; $i++) { 
                           $userbiz=$bizcard->getuserdata($usertaxvalue['userid']);      
                          ?>
				   <div class="col-lg-6">
			      <div class="mybizcard-box">
				    <div class="row">
					<div class="col-sm-4">
				        <a href="userprofile.php?id=<?php echo $userbiz['id'];?>">
					  <div class="mybiz-img">
					     <img src="images/user/<?php echo $userbiz['image'];?>" alt="">
                                             <?php if($userbiz['image']==''){ echo '<img src="images/edit-pic.png" alt="image">';}else{echo '<img src="images/user/'.$userbiz['image'].' alt="">';}?>
                                             
					  </div>
					  </a>
					  </div>
					  <div class="col-sm-8">
					  <div class="mybizcrd-txt">
					     <h3><?php echo $userbiz['name']; ?></h3>
						 <p><?php echo $userbiz['about'];?></p>
						 <a href="#">Request </a>
						 <a href="#">mail </a>
					  </div>
					  </div>
					</div>
				  </div>
				     </div>
			   <?php   }  /////for  
                                 } ///////foreach
                                 }  ///user tax condition
                                 } /////////if approval=y
                       }
                       }?>
			
			
			
			 </div>
			</div>
		 </div>

        
   <?php include("userfooter.php"); ?>     
        </div>
   