<?php include("header.php"); ?>



<section class="contact-section" id="contact">
 <div class="container">

   <div class="row contact_details">
   <div class="content-wrapper">
   <div class="success-part">
			 <img src="images/success-icon.png" alt="">
			 <h2>Successfully Submitted</h2>
			 <h5>We Will Contact You As soon as Possible...</h5>
			 <a href="index.php"  class="btn btn-success" style="margin-top:30px;">Return to Home</a>
			 </div>
			 </div>
   </div>
 </div>
</section>
