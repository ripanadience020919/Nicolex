<?php include("userheader.php"); ?>
 <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
   <?php include("sidebar.php"); ?>   <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
 
            <div class="page-header">
              <h3 class="page-title">Payment Gateway </h3>
            </div>
			<div class="radio-button-choose">
			 <input type="radio" id="business-register" name="new-register" value="business-register" checked> <label for="business-register">Card</label>
             <input type="radio" id="vehicle-register" name="new-register" value="vehicle-register"> <label for="vehicle-register">Net  Banking</label>
           </div>
			 
			 <div class="business-register business-new show">
			    <div class="payment-gateway-tab">
				 <ul class="nav nav-tabs" role="tablist">
	               <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab"><img src="images/card-1.jpg" alt=""></a></li>
	               <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab"><img src="images/card-2.jpg" alt=""></a></li>
	              <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab"><img src="images/card-3.jpg" alt=""></a></li>
                </ul>
				<div class="tab-content">
	              <div class="tab-pane active" id="tabs-1" role="tabpanel">
		            <form class="card-form-payment" method="get" action="payment-bill.html">
					  <div class="row">
					    <div class="col-md-12">
				       <div class="input-field">
					   <label class="input-label"> Card Number  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				     </div>
					 <div class="col-md-6">
				       <div class="input-field">
					   <label class="input-label"> Exp Date  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				    <div class="col-md-6">
				       <div class="input-field">
					   <label class="input-label"> Code CVV <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				   <div class="col-md-12">
				       <div class="input-field">
					   <label class="input-label"> Cardholder Name  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div><!--
				   <div class="col-md-12">
				  <div class="submit-form-btn">
					 <a href="paymentbill.php?id=<?php echo $_GET['id']; ?>&text=<?php echo $_GET['text']; ?>">   <input type="button" value="Pay"></a>
					 </div>
				  </div>-->
					  </div>
					</form>
                          
	              </div>
				   <div class="tab-pane" id="tabs-2" role="tabpanel">
		            <form class="card-form-payment">
					  <div class="row">
					    <div class="col-md-12">
				       <div class="input-field">
					   <label class="input-label"> Card Number  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				     </div>
					 <div class="col-md-6">
				       <div class="input-field">
					   <label class="input-label"> Exp Date  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				    <div class="col-md-6">
				       <div class="input-field">
					   <label class="input-label"> Code CVV <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				   <div class="col-md-12">
				       <div class="input-field">
					   <label class="input-label"> Cardholder Name  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				  <!--
				   <div class="col-md-12">
				  <div class="submit-form-btn">
					 <a href="paymentbill.php?id=<?php echo $_GET['id']; ?>&text=<?php echo $_GET['text']; ?>">   <input type="button" value="Pay"></a>
					 </div>
				  </div>-->
					  </div>
					</form>
	              </div>
				  <div class="tab-pane" id="tabs-3" role="tabpanel">
		            <form class="card-form-payment">
					  <div class="row">
					    <div class="col-md-12">
				       <div class="input-field">
					   <label class="input-label"> Card Number  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				     </div>
					 <div class="col-md-6">
				       <div class="input-field">
					   <label class="input-label"> Exp Date  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				    <div class="col-md-6">
				       <div class="input-field">
					   <label class="input-label"> Code CVV <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				   <div class="col-md-12">
				       <div class="input-field">
					   <label class="input-label"> Cardholder Name  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				   <!--
				   <div class="col-md-12">
				  <div class="submit-form-btn">
					 <a href="paymentbill.php?id=<?php echo $_GET['id']; ?>&text=<?php echo $_GET['text']; ?>">   <input type="button" value="Pay"></a>
					 </div>
				  </div>-->
					  </div>
					</form>
	              </div>
				
				 </div>
			
				   <div class="col-md-12">
                                       
              <div id="government"></div>
				  <div class="submit-form-btn">
                                      
				   <a  onclick="bill('<?php echo $_GET['id'];?>','<?php echo $_GET['text']; ?>','<?php echo $_GET['amount'];?>')">   <input type="button" id="send" value="Pay"></a>
					 </div>
				  </div>
                            </div>
			 </div>
<script>
    function bill(id,text,amount){
         var button = $('#send');
    button.prop('disabled', true);
        //  alert(id,text); 
       var dataString ='id='+id+'&text='+text+'&amount='+amount;
         $.ajax({
                type:'POST',
                url:'ajaxdata.php',
                data: dataString,
                success:function(html){ 
                   window.location.assign("http://nicolex.finntechetan.com/paymentbill.php?id="+id+"&text="+text);
               }
            }); 
    }
    </script>
			 <div class="vehicle-register business-new">
			  <form class="net-banking">
			     <h3>Welcome To Personal Banking</h3>
				 <div class="row personal-banking-row">
				 <div class="col-md-12">
				 <div class="welcome-head">Login</div>
				 </div>
				  <div class="col-md-12">
				       <div class="input-field">
					   <label class="input-label">Select Bank  <sup> *</sup></label>
					  <select id="Business-selector" name="bank">
                        <option value="ACCESS BANK">ACCESS BANK</option>
                        <option value="CITI BANK">CITI BANK</option>
                        <option value=" ECO BANK"> ECO BANK</option>
                        <option value="FCMB ">FCMB</option>
                        <option value="FIDELITY  BANK">FIDELITY  BANK</option>
                        <option value=" FIRST  BANK"> FIRST  BANK</option>
                        <option value="GTB">GTB</option>
                        <option value="HERITAGE  BANK">HERITAGE  BANK</option>
                        <option value=" KEYSTONE  BANK"> KEYSTONE  BANK</option>
                        <option value="POLARIS  BANK">POLARIS  BANK</option>
                        <option value="PROVIDUS  BANK">PROVIDUS  BANK</option>
                        <option value=" STANBIC  BANK"> STANBIC  BANK</option>
                        <option value="STANDARD CHARTERED  BANK">STANDARD CHARTERED  BANK</option>
                        <option value=" STERLING   BANK"> STERLING   BANK</option>
                        <option value="SUN TRUST  BANK">SUN TRUST  BANK</option>
                        <option value="UBA">UBA</option>
                        <option value=" UNION   BANK"> UNION   BANK</option>
                        <option value=" UNITY   BANK"> UNITY   BANK</option>
                        <option value="WEMA   BANK">WEMA   BANK</option>
                        <option value="ZENITH   BANK">ZENITH   BANK</option>
                     </select>
					 </div>
				   </div>
				  <div class="col-md-12">
				       <div class="input-field">
					   <label class="input-label"> User Name  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				    <div class="col-md-12">
				       <div class="input-field">
					   <label class="input-label">Password  <sup> *</sup></label>
					   <input type="text" class="">
					 </div>
				   </div>
				   
				   <div class="col-md-12">
				   <div class="table-all-see-btn business-inner-button text-center">
			       <a href="#" class="pay-download">Login</a>
				    <a href="#" class="view-list">Reset</a>
			  </div>
			  </div>
			  <div class="col-md-12">
			  <div class="net-banking-link">
			  <a href="#">New User ?  Click here</a>
			  <a href="#">Forgot Password?</a>
			  </div>
			  </div>
				 </div>
			  </form>
			 </div>
			 
			
			 
		  </div>

         <?php include("userfooter.php"); ?>    
        </div>
      </div>
    </div>
   <script>
$(document).ready(function(){
    $('.radio-button-choose input[type="radio"]').click(function(){
        var inputValue = $(this).attr("value");
        var targetBox = $("." + inputValue);
        $(".business-new").not(targetBox).hide();
        $(targetBox).show();
    });
});
</script>
  </body>
</html>