<?php
 ob_start();
session_start();
define('DB_SERVER','localhost');
define('DB_USER','u419624212_nicolex');
define('DB_PASS' ,'nicolex');
define('DB_NAME', 'u419624212_nicolex');
class Users {
    
      function __construct()
	{
            
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
$this->db=$con;
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }
	}
   public function setpassword($password,$uid)
 {  $today=date("Y-m-d");
 $res="update user set password='".$password."'  where id='$uid'";
   $sql1=mysqli_query($this->db,$res);
   $msg="Password Changed Successfully ";
 return $msg;
 } 
   public function setprofile($name,$email,$mobile,$state,$government,$address1,$address2,$about,$image,$uid)
 {  $today=date("Y-m-d");
  $res="update user set name='".$name."',email='".$email."',address1='".$address1."',address2='".$address2."',mobile='".$mobile."',image='".$image."',state='".$state."',government='".$government."',about='$about'  where id='$uid'";
   $sql1=mysqli_query($this->db,$res);
   $msg="Profile Successfully Updated";
 return $msg;
 } 
          
public function  qrcode($rno,$text){
include('operation/qr/libs/phpqrcode/qrlib.php');
    function getUsernameFromEmail($email) {
	$find = '/';
	$pos = strpos($email, $find);
	$username = substr($email, 0, $pos);
	return $username.rand(9999,100000);
}
 $tempDir = 'operation/qr/temp/'; 
	$filename = getUsernameFromEmail($rno);
	$codeContents = 'http://nicolex.finntechetan.com/scanqr.php?receiptno='.$rno.'&type='.$text.''; 
	QRcode::png($codeContents, $tempDir.''.$filename.'.png', QR_ECLEVEL_L, 5);
	 $qr=$filename.'.png';
	return $qr;
}
public function makerecipt($state,$government,$text)
 {  	
		$str=$state;
	$count=str_word_count($str);
if($count=='1'){ $letter=substr($str,0,2);}
else{
	$words = explode(" ", $str); $letter = "";
        foreach ($words as $value) {   $letter .= substr($value, 0, 1);} 
}
$g=$government;
 $count1=str_word_count($g);
if($count1=='1'){ $letter1=substr($g,0,2);}else{
	$words1 = explode(" ", $g);$letter1 = "";
foreach ($words1 as $value1) {   $letter1 .= substr($value1, 0, 1);} }
 $rno= $letter.'/'.$letter1.'/'.$text.'/'.rand(9999,100000);
 return $rno;
 }   
 public function getallpaytaxlist($userid)
 {  $user=array();
        $sql="select id,name,createat,qrcode from business_bill where userid=".$userid."  union select id,title,createat,qrcode from property_bill where userid=".$userid." union select id,ownername,createat,qrcode from vehicle_bill where userid=".$userid."";
 $result=mysqli_query($this->db,$sql);
         $rowcount=mysqli_num_rows($result);
 if($rowcount>0){
 while ($row = mysqli_fetch_assoc($result)) {
     array_push($user,$row);
 }
 return $user;
 }else{ return 'nodata';}
 }     
     
 public function getcomparepcn($userid,$code,$table)
 {  if($table=='BUS'){ $sql="select * from business_bill where receiptno='$code' and userid='$userid'";}
elseif($table=='PRO'){ $sql="select * from property_bill where receiptno='$code' and userid='$userid'";}  
else{ $sql="select * from vehicle_bill where receiptno='$code' and userid='$userid'";}
$result=mysqli_query($this->db,$sql);
         $rowcount=mysqli_num_rows($result);
 if($rowcount>0){ return 'done';
 }else{ return 'nodata';}
 }     
 
   public function getallpbvlist($userid)
 {  $user=array();
      echo  $sql="select id,name,paymentdate,billid,itis from business where userid=".$userid."  union select id,title,paymentdate,billid,itis from property where userid=".$userid." union select id,ownername,paymentdate,billid,itis from vehicle where userid=".$userid."";
 $result=mysqli_query($this->db,$sql);
         $rowcount=mysqli_num_rows($result);
 if($rowcount>0){
 while ($row = mysqli_fetch_assoc($result)) {
     array_push($user,$row);
 }
 return $user;
 }else{ return 'nodata';}
 }     
 public function getpropertybilltable($type,$state,$government)
 {  $_user1=array();
     $sql="SELECT * from propertyrate where type='".$type."' and state='".$state."' and government='".$government."'";
 $result=mysqli_query($this->db,$sql);
 while($row = mysqli_fetch_assoc($result)){
     $user1=$row;
 }
 return $user1;
 }        
   public function getvehiclebilltable($type,$state,$government)
 {  $user1=array();
     $sql="SELECT * from vehiclerate where type='".$type."' and state='".$state."' and government='".$government."'";
 $result=mysqli_query($this->db,$sql);
 while($row = mysqli_fetch_assoc($result)){
     $user1=$row;
 }
 return $user1;
 }        
  public function getbusinessbilltable($businesstype,$size,$state,$government)
 {  
        $sql="SELECT * from businessrate where bid='".$businesstype."' and  category='".$size."' and state='".$state."' and government='".$government."'";
 $result=mysqli_query($this->db,$sql);
 $row = mysqli_fetch_assoc($result);
     $user1=$row;
 return $user1;
 }   
  public function getfilterdata($from,$too,$userid)
 {  $user=array();
        $sql="SELECT id,name,createat,qrcode FROM business_bill where createat between '".$from."' and '".$too."' and userid='".$userid."' union  SELECT id,title,createat,qrcode FROM property_bill where createat between '".$from."' and '".$too."' and userid='".$userid."' union SELECT id,ownername,createat,qrcode FROM vehicle_bill where createat between '".$from."' and '".$too."' and userid='".$userid."'";
 $result=mysqli_query($this->db,$sql);
         $rowcount=mysqli_num_rows($result);
 if($rowcount>0){
 while ($row = mysqli_fetch_assoc($result)) {
     array_push($user,$row);
 }
 return $user;
 }else{ return 'nodata';}
 }   
  public function setcontactform($name,$email,$mobile,$state,$government,$msg)
 {  $today=date("Y-m-d");
   $sql="insert into `webcontact`(`name`, `email`, `mobile`, `msg`, `state`, `government`, `dateat`) values ('$name','$email','$mobile','$msg','$state','$government','$today')";
	$result = mysqli_query($this->db,$sql);
 return 'done';
 }      
    public function getlogin($username,$password)
 { 
  $today=date("Y-m-d H:i:s");
        $sql="SELECT * from user where username='".$username."' ";
 $result=mysqli_query($this->db,$sql);
         $rowcount=mysqli_num_rows($result);
 if($rowcount>0){
 $row = mysqli_fetch_array($result);     
     if($password==$row['password']){ $status='1';$msg="Login"; 
     $_SESSION['name']=$row['name'];  $_SESSION['id']=$row['id'];
     $update= mysqli_query($this->db,"update user set lastlogin='".$today."', status='Y' where id='".$row['id']."'");
     }else{ $status='0';$msg='Password Not Match';  }
 }else{ $status='0';$msg='Username Not Exist'; }
 return array($status,$msg,$update);
 }    
    public function getdata($tablename)
 { 
        $sql="select * from ".$tablename."";
 $result=mysqli_query($this->db,$sql);
 while ($row = mysqli_fetch_array($result)) {
     $user[]=$row;
 }
 return $user;
 }
 public function getstate()
 { 
        $user=array();
        $sql="SELECT * from `statewithgovernment` GROUP BY state ";
 $result=mysqli_query($this->db,$sql);
 while ($row = mysqli_fetch_array($result)) {
     $user[]=$row;
 }
 return $user;
 }
        public function getbizcarddata($userid)
 { 
        $user=array();
        $sql="SELECT distinct(size) from business_bill where userid='".$userid."' ";
 $result=mysqli_query($this->db,$sql);
 if(mysqli_num_rows($result)>0){
 while ($row = mysqli_fetch_array($result)) {
    $sql1="SELECT distinct(userid) from business_bill where size='".$row['size']."' and userid!=".$userid." ";
 $res=mysqli_query($this->db,$sql1);
 if(mysqli_num_rows($res)>0){
 while ($row1 = mysqli_fetch_assoc($res)) {
 array_push($user,$row1);
 }
 }else{ return 'nodata';}
 }
 return $user;
 }else{ return 'pay';}
 }
 public function getwheredata($tablename,$wherename,$matchname)
 { 
        $user=array();
          $sql="SELECT * from ".$tablename." where ".$wherename."='".$matchname."' ";
 $result=mysqli_query($this->db,$sql);
         $rowcount=mysqli_num_rows($result);
 if($rowcount>0){
 while ($row = mysqli_fetch_assoc($result)) {
     array_push($user,$row);
 }
 return $user;
 }else{ return 'nodata';}
 }
 public function insert($name,$username,$email,$mobile,$gender,$dob,$address1,$address2,$password)
	{
     $sql="INSERT INTO `user`(`name`, `username`, `email`, `mobile`, `gender`, `dob`, `address1`, `address2`, `password`) VALUES ('$name','$username','$email','$mobile','$gender','$dob','$address1','$address2','$password')";
	$result = mysqli_query($this->db,$sql);
	$id= mysqli_insert_id($this->db);
        $_SESSION['name']=$name;  $_SESSION['id']=$id;
        return $result;
	}
  public function getuserdata($id)
 { 
        $sql="select * from user where id='$id'";
 $result=mysqli_query($this->db,$sql);
$row = mysqli_fetch_assoc($result);
     $userdata=$row;
 return $userdata;
 }
 public function setuserlogout()
 { 
        mysqli_query($this->db,"update user set status='N' where id=".$_SESSION['id']);
	unset($_SESSION['id']);
	unset($_SESSION['name']);
	session_destroy();
 return 'done';
 }
 }

 
 class mainfuntion
{
     function __construct()
	{
            
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
$this->db=$con;
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }
	}
     public function insertbusiness($userid,$name,$address,$size,$type,$pname,$pno,$email,$bno,$state,$government,$year)
	{
            $ret=mysqli_query($this->db,"insert into `business`(`name`, `address`, `type`, `email`, `size`, `businessmobile`, `personcontact`, `personmobile`, `state`, `government`, `yearvalidity`, `userid` ,`itis`) VALUES  ('$name','$address','$type','$email','$size','$bno','$pname','$pno','$state','$government','$year','$userid','business')");
	$id= mysqli_insert_id($this->db);
   		$sql=mysqli_query($this->db,"update user set business=business+1 where id='$userid'");
        return $id;
	}
        public function insertbusinessbill($bid,$userid,$name,$address,$size,$type,$pname,$pno,$email,$bno,$state,$government,$year,$amount,$rno,$qrcode,$description)
	{   $date= date("Y-m-d H:i:s");       $today=date("Y-m-d");
        $sql="SELECT * from business_bill where bid='".$bid."' ";
 $result=mysqli_query($this->db,$sql);
 if(mysqli_num_rows($result)>0){  return 'no';  }else{
            $query="insert into `business_bill`(`bid`,`name`, `address`, `type`, `email`, `size`, `businessmobile`, `personcontact`, `personmobile`, `state`, `government`, `yearvalidity`, `createat`, `userid`, `amount`, `receiptno`, `qrcode`, `description`) VALUES ('$bid','$name','$address','$type','$email','$size','$bno','$pname','$pno','$state','$government','$year','$date','$userid','$amount','$rno','$qrcode','$description')";
            $ret=mysqli_query($this->db,$query);
            $id= mysqli_insert_id($this->db);
            $sql=mysqli_query($this->db,"update business set billstatus='C', billid='$id',paymentdate='$today' where id='$bid'");
        return $id;
	}
	}
        public function updatebusiness($id,$name,$address,$size,$type,$pname,$pno,$email,$bno,$state,$government,$year)
	{
            $ret=mysqli_query($this->db,"update business set name='$name',address='$address',type='$type',email='$email',size='$size',businessmobile='$bno',personcontact='$pno',state='$state',government='$government',yearvalidity='$year' where id='$id'");
         $id=$id;
            return $id;
	}
      public function insertvehicle($userid,$name,$registrationno,$chasisno,$vehiclemake,$manufactreyear,$government,$state,$usetype,$year,$address,$mobile)
	{ 
	$ret=mysqli_query($this->db,"INSERT INTO `vehicle`( `userid`, `ownername`, `vehicleregistrationno`, `chasisno`, `vehiclemake`, `manufactureyear`, `government`, `state`, `usetype`,`validityyear`,`itis`,`address`,`mobile`)VALUES('$userid','$name','$registrationno','$chasisno','$vehiclemake','$manufactreyear','$government','$state','$usetype','$year','vehicle','$address','$mobile')");
	$id= mysqli_insert_id($this->db);
   		$sql=mysqli_query($this->db,"update user set vehicle=vehicle+1 where id='$userid'");
        return $id;
	}
        public function insertvehiclebill($userid,$name,$registrationno,$chasisno,$vehiclemake,$manufactreyear,$government,$state,$usetype,$year,$rno,$amount,$qrcode,$vid,$desc,$address,$mobile)
	{  $date= date("Y-m-d H:i:s"); $today= date("Y-m-d");
	  $sql="SELECT * from vehicle_bill where vid='".$vid."' ";
 $result=mysqli_query($this->db,$sql);
 if(mysqli_num_rows($result)>0){  return 'no';  }else{
	$query="INSERT INTO `vehicle_bill`( `userid`, `ownername`, `vehicleregistrationno`, `chasisno`, `vehiclemake`, `manufactureyear`, `government`, `state`, `usetype`,`validityyear`,`createat`, `receiptno`, `amount`,`qrcode`, `vid`, `description`,`address`,`mobile`)VALUES('$userid','$name','$registrationno','$chasisno','$vehiclemake','$manufactreyear','$government','$state','$usetype','$year','$date','$rno','$amount','$qrcode','$vid','$desc','$address','$mobile')";
	$ret=mysqli_query($this->db,$query);
            $id= mysqli_insert_id($this->db);
            $sql=mysqli_query($this->db,"update vehicle set billstatus='C', billid='$id',paymentdate='$today' where id='$vid'");
       return $id;
	} }
         public function updatevehicle($id,$name,$registrationno,$chasisno,$vehiclemake,$manufactreyear,$government,$state,$usetype,$year,$address,$mobile)
	{
	$ret=mysqli_query($this->db,"update vehicle set `ownername`='$name', `vehicleregistrationno`='$registrationno', `chasisno`='$chasisno', `vehiclemake`='$vehiclemake', `manufactureyear`='$manufactreyear', `government`='$government', `state`='$state', `usetype`='$usetype',`validityyear`='$year',`address`='$address',`mobile`='$mobile' where id='$id'");
     	 return $id;
	}
         public function insertproperty($userid,$title,$mobile,$address1,$address2,$government,$state,$usetype,$year)
	{ 
	$ret=mysqli_query($this->db,"INSERT INTO `property`(`userid`, `title`,`mobile`, `address1`, `address2`, `state`,`government`,`propertytype`, `validityyear`,`itis`)VALUES('$userid','$title','$mobile','$address1','$address2','$government','$state','$usetype','$year','property')");
	$id= mysqli_insert_id($this->db);
   		$sql=mysqli_query($this->db,"update user set property=property+1 where id='$userid'");
        return $id;
	}
          public function updateproperty($id,$title,$mobile,$address1,$address2,$government,$state,$usetype,$year)
	{ 
	$ret=mysqli_query($this->db,"update property set `title`='$title',`mobile`='$mobile', `address1`='$address1', `address2`='$address2', `state`='$state',`government`='$government',`propertytype`='$usetype', `validityyear`='$year' where id='$id'");
      return $id;
	}
          public function insertpropertybill($userid,$title,$mobile,$address1,$address2,$government,$state,$propertytype,$year,$rno,$amount,$qrcode,$pid,$desc)
	{  $date= date("Y-m-d H:i:s"); $today= date("Y-m-d");
	
	  $sql="SELECT * from property_bill where pid='".$pid."' ";
 $result=mysqli_query($this->db,$sql);
 if(mysqli_num_rows($result)>0){  return 'no';  }else{
	$ret1="INSERT INTO `property_bill`(`userid`, `title`,`mobile`, `address1`, `address2`, `state`,`government`,`propertytype`, `validityyear`,`receiptno`, `amount`,`description`, `qrcode`,`pid`)VALUES('$userid','$title','$mobile','$address1','$address2','$government','$state','$propertytype','$year','$rno','$amount','$desc','$qrcode','$pid')";
	$ret=mysqli_query($this->db,$ret1);
            $id= mysqli_insert_id($this->db);
            $sql=mysqli_query($this->db,"update vehicle set billstatus='C', billid='$id',paymentdate='$today' where id='$pid'");
       return $id;
	}   }
         public function insertsupport($userid,$name,$email,$mobile,$query,$pcnno)
	{ 
 $today= date('Y-m-d');
		$rt="INSERT INTO  `support`(`name`, `email`, `mobile`, `query`, `pcnno`, `userid`, `dateat`) VALUES ('".$name."','".$email."','".$mobile."','".$query."','".$pcnno."','".$userid."','$today')";
   		$ret=mysqli_query($this->db,$rt);
                $id= mysqli_insert_id($this->db);
	  return $id;
	}
   public function insertadd($userid,$name,$desc,$filename,$filetmp)
	{ 
 $today= date('Y-m-d');
$image=$filename;
		$path="images/";
		$img=rand(99,1000).$image;
		$upload=$path.$img;
		if($image!="")
		{	move_uploaded_file($filetmp,$upload);	
	$rt="INSERT INTO `advertisement`(`userid`, `name`, `description`, `file`,`dateat`) VALUES ('$userid','".$name."','".$desc."','$img','$today')";	
        $ret=mysqli_query($this->db,$rt);
        $id= mysqli_insert_id($this->db);
	  return $id;
	} 
        }
}

    ob_flush();
?>