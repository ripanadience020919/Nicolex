<?php
function gettime($paydate)
 {   
$datestr = date('Y-m-d', strtotime($paydate .'+1 years'));
$date=strtotime($datestr);
$diff=$date-time();//time returns current time in seconds
$days=floor($diff/(60*60*24));//seconds/minute*minutes/hour*hours/day)
$hours=round(($diff-$days*60*60*24)/(60*60));
$returndate=$days.' days '.$hours.' hours';
 return $returndate;
 }     
?>