       <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
           
            <li class="nav-item">
              <a class="nav-link" href="userindex.php">
                <span class="menu-title">Dashboard</span>
                <i class="fas fa-tachometer-alt menu-icon"></i>
              </a>
            </li>
           
            <li class="nav-item">
              <a class="nav-link" href="payform.php">
                <span class="menu-title"> Pay</span>
             <i class="fab fa-paypal menu-icon"></i>
              </a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="history.php">
                <span class="menu-title">Payment History</span>
              <i class="fas fa-history menu-icon"></i>
              </a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="#">
                <span class="menu-title">Info</span>
              <i class="fas fa-info-circle  menu-icon"></i>
              </a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="#">
                <span class="menu-title">Chat / Buzz</span>
              <i class="fas fa-comments  menu-icon"></i>
              </a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="bizcards.php">
                <span class="menu-title">MyBizCards</span>
              <i class="fas fa-address-card menu-icon"></i>
              </a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="support.php">
                <span class="menu-title">Contact / Support</span>
              <i class="fas fa-headset menu-icon"></i>
              </a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="advertisment.php">
                <span class="menu-title">Council Mall</span>
              <i class="fas fa-ad menu-icon"></i>
              </a>
            </li>
				<li class="nav-item">
              <a class="nav-link" href="faq.php?text=admin">
                <span class="menu-title">FAQ</span>
              <i class="fas fa-ad menu-icon"></i>
              </a>
            </li>
			
          </ul>
        </nav>
    